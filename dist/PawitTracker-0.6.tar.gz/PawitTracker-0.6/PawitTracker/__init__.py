#__init__.py
from PawitTracker.SmartTracker import SmartCovid
